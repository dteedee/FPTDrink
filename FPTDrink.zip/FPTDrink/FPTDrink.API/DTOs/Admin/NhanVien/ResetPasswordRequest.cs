namespace FPTDrink.API.DTOs.Admin.NhanVien
{
	public class ResetPasswordRequest
	{
		public string NewPassword { get; set; } = "123456";
	}
}


