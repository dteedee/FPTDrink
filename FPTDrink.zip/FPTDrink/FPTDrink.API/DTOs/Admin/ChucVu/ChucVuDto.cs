namespace FPTDrink.API.DTOs.Admin.ChucVu
{
	public class ChucVuDto
	{
		public int Id { get; set; }
		public string? TenChucVu { get; set; }
		public string? MoTa { get; set; }
		public int? Status { get; set; }
		public DateTime? CreatedDate { get; set; }
		public DateTime? ModifiedDate { get; set; }
	}
}


