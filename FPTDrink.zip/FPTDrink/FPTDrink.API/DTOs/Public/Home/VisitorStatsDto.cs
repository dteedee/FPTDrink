namespace FPTDrink.API.DTOs.Public.Home
{
	public class VisitorStatsDto
	{
		public string HomNay { get; set; } = "0";
		public string HomQua { get; set; } = "0";
		public string TuanNay { get; set; } = "0";
		public string TuanTruoc { get; set; } = "0";
		public string ThangNay { get; set; } = "0";
		public string ThangTruoc { get; set; } = "0";
		public string TatCa { get; set; } = "0";
		public int VisitorsOnline { get; set; }
	}
}


