namespace FPTDrink.Core.Models.Reports
{
	public class RevenuePoint
	{
		public System.DateTime Date { get; set; }
		public decimal DoanhThu { get; set; }
		public decimal LoiNhuan { get; set; }
	}
}


