namespace FPTDrink.Core.Models.Reports
{
	public class CustomerSummaryInfo
	{
		public string? MaKhachHang { get; set; }
		public string? TenKhachHang { get; set; }
		public string? Email { get; set; }
		public string? SoDienThoai { get; set; }
	}
}


