namespace FPTDrink.Core.Constants
{
	public static class AppCultures
	{
		public const string DefaultCulture = "vi-VN";
	}
}


